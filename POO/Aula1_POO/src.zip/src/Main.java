import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Aluno a1 = new Aluno(); //metodo construtor
        // a1.nome = "Paulo POO";
        //  a1.idade = 28;
        //a1.matricula = 123434;
        //  a1.altura = 1.23;
        //    a1.mostrarDados();


//        ArrayList<Aluno> alunos = new ArrayList<>();
//        alunos.add(a1);
//        alunos.add(new Aluno());
        //      Aluno a2 = new Aluno();
        //    a2.nome = "Hector herança";
        //   a2.idade = 26;
        //   a2.matricula = 123432;
        //   a2.altura = 1.3;
        //   Aluno a1 = new Aluno("Paula",25,1.1,12332);
        //    Aluno a2 = new Aluno("Paula",25,1.1,12332);
        //    List<Aluno> alunos = new ArrayList<>();
        //   alunos.add(a1);
        //   alunos.add(a2);
        //    for(Aluno aluno: alunos){
        //        aluno.mostrarDados();
        //   }
//        System.out.println("Quantas rodadas vai ter?");
//        int rodada = sc.nextInt();
//        Personagem p1 = new Personagem("João", Personagem.Tipo.Guerreiro,100,100);
//        Personagem p2 = new Personagem("Rannyer",Personagem.Tipo.Arqueiro,120,90);
//        for(int i = 0; i<=rodada;i++){
//            p1.atacar(p2);
//            p2.receberDano(10,p1);
//            p1.morreu();
//            p1.receberDano(10,p2);
//            p2.morreu();
//        }
//        PetVirtual pet1 = new PetVirtual("João",82,100);
//        System.out.println("quanto quer alimentar?");
//        int quantidade = sc.nextInt();
//        pet1.alimentar(quantidade);
//        pet1.felicidade(quantidade);//fiquei com preguiça de perguntar, então peguei essa quantidade
//        pet1.fome();
//        pet1.status();
//        DiarioSecreto ds1 = new DiarioSecreto("Eu","1234","Texto é incrível");
//        System.out.println("Digite a senha:");
//        String senha = sc.next();
//      ds1.ler(senha);
        // Lampada lambda = new Lampada(false,"vermelho");
        // lambda.desligar();
        //   lambda.trocarCor("Vermelho ainda mais vermelho");
        //  lambda.mostrarEstado();
//     Robo rb = new Robo("João",100);
//        rb.executarTarefa("Comer");
//        rb.status();
//        rb.recarregar();
//        rb.status();
//        PlaylistMusical playlist = new PlaylistMusical("Definitivamente músicas =)");
//
//        playlist.adicionarMusica("Cerimony");
//        playlist.adicionarMusica("Karma");
//        playlist.adicionarMusica("Hotel California");
//
//        playlist.tocarProxima();
//        playlist.tocarProxima();
//        playlist.tocarProxima();
//        playlist.tocarProxima();


    }
}